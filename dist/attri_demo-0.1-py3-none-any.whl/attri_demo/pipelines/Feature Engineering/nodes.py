
from string import ascii_letters
import random
import pandas as pd


def statistical_feature_engineering(df):
    return df

def SNA_feature_engineering(df):
    return df

def feature_selection(df,df2):
    return df

def feature_transformation(df,df2,df3):
    return df


